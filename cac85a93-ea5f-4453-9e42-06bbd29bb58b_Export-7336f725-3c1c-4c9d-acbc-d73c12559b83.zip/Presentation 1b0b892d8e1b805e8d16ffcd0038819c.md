# Presentation

[Ivan Gridin - Learning Genetic Algorithms with Python_ Empower the performance of Machine Learning and AI models with the capabilities of a powerful search algorithm (English Edition)-BPB Publications.pdf](Ivan_Gridin_-_Learning_Genetic_Algorithms_with_Python__Empower_the_performance_of_Machine_Learning_and_AI_models_with_the_capabilities_of_a_powerful_search_algorithm_(English_Edition)-BPB_Publications.pdf)

- Ch.3
    
    [learrning genetic algorithm with python_ch_3.pdf](learrning_genetic_algorithm_with_python_3%EC%9E%A5.pdf)
    
    [Translation](Translation%201afb892d8e1b809d88cfd342404a661c.md)
    
    [Program code](Program%20code%201b0b892d8e1b80c2bb08d4422d10059d.md)